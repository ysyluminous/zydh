package com.yaosiyuan.model;

import java.util.List;

/**
 * @ClassName CatPage
 * @Description TODO
 * @Author yaosiyuan
 * @Date 2019/4/24 0:09
 * @Version 1.0
 **/
public class CatPage  {

    private List<Bar> bars;

    public List<Bar> getBars() {
        return bars;
    }

    public void setBars(List<Bar> bars) {
        this.bars = bars;
    }
}
