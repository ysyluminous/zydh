package com.yaosiyuan.service;

import com.yaosiyuan.model.User;

/**
 * @ClassName IUserService
 * @Description TODO
 * @Author yaosiyuan
 * @Date 2019/4/22 21:32
 * @Version 1.0
 **/
public interface IUserService {
    public User getUserById(int userId);
}
